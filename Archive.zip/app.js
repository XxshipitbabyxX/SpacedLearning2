import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  addDoc,
  getDocs,
  doc,
  updateDoc,
  setDoc,
  getDoc
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

// 🔥 Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyAwLEqEx3Pn3rnpX9Q6ZABAbkQf4Nsh5ls",
  authDomain: "spacedlearning-d3b5f.firebaseapp.com",
  projectId: "spacedlearning-d3b5f",
  storageBucket: "spacedlearning-d3b5f.firebasestorage.app",
  messagingSenderId: "276082819889",
  appId: "1:276082819889:web:9c6230fa97a4d9e86d2610"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth();
const db = getFirestore();

let currentUser = null;
let currentGroupId = null;
let studyCards = [];
let currentCardIndex = 0;
let studiedToday = false;

// ================= AUTH =================

document.getElementById("loginBtn").onclick = async () => {
  const provider = new GoogleAuthProvider();
  await signInWithPopup(auth, provider);
};

document.getElementById("logoutBtn").onclick = () => signOut(auth);

onAuthStateChanged(auth, async user => {
  if (user) {
    currentUser = user;
    document.getElementById("auth-section").classList.add("hidden");
    document.getElementById("app").classList.remove("hidden");
    await ensureStatsDoc();
    await loadStreak();
    loadGroups();
  }
});

// ================= STREAK =================

async function ensureStatsDoc() {
  const statsRef = doc(db, "users", currentUser.uid, "meta", "stats");
  const snap = await getDoc(statsRef);

  if (!snap.exists()) {
    await setDoc(statsRef, {
      currentStreak: 0,
      longestStreak: 0,
      lastStudyDate: null
    });
  }
}

async function loadStreak() {
  const statsRef = doc(db, "users", currentUser.uid, "meta", "stats");
  const snap = await getDoc(statsRef);
  const data = snap.data();

  document.getElementById("streak").innerText = data.currentStreak;
}

async function updateStreakIfNeeded() {
  if (studiedToday) return;

  const statsRef = doc(db, "users", currentUser.uid, "meta", "stats");
  const snap = await getDoc(statsRef);
  const data = snap.data();

  const today = new Date().toDateString();
  const last = data.lastStudyDate;

  let newStreak = data.currentStreak;

  if (!last) {
    newStreak = 1;
  } else {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);

    if (new Date(last).toDateString() === yesterday.toDateString()) {
      newStreak += 1;
    } else if (new Date(last).toDateString() !== today) {
      newStreak = 1;
    }
  }

  await updateDoc(statsRef, {
    currentStreak: newStreak,
    longestStreak: Math.max(newStreak, data.longestStreak),
    lastStudyDate: today
  });

  document.getElementById("streak").innerText = newStreak;
  studiedToday = true;
}

// ================= GROUPS =================

async function loadGroups() {
  const snapshot = await getDocs(collection(db, "users", currentUser.uid, "groups"));
  const container = document.getElementById("groups");
  container.innerHTML = "";

  snapshot.forEach(docSnap => {
    const btn = document.createElement("button");
    btn.innerText = docSnap.data().name;
    btn.onclick = () => openGroup(docSnap.id, docSnap.data().name);
    container.appendChild(btn);
  });
}

document.getElementById("addGroupBtn").onclick = async () => {
  const name = newGroupName.value;
  await addDoc(collection(db, "users", currentUser.uid, "groups"), {
    name,
    createdAt: new Date()
  });
  loadGroups();
};

async function openGroup(id, name) {
  currentGroupId = id;
  document.getElementById("groupView").classList.remove("hidden");
  document.getElementById("currentGroupName").innerText = name;
  await calculateMastery();
}

// ================= MASTERY =================

async function calculateMastery() {
  const snapshot = await getDocs(collection(db, "users", currentUser.uid, "cards"));
  let total = 0;
  let mastered = 0;

  snapshot.forEach(docSnap => {
    const data = docSnap.data();
    if (data.groupId === currentGroupId) {
      total++;
      if (data.interval >= 14) mastered++;
    }
  });

  const percent = total === 0 ? 0 : Math.round((mastered / total) * 100);
  document.getElementById("mastery").innerText = percent;
}

// ================= ADD CARD =================

document.getElementById("addCardBtn").onclick = async () => {
  await addDoc(collection(db, "users", currentUser.uid, "cards"), {
    groupId: currentGroupId,
    word: word.value,
    translation: translation.value,
    transcription: transcription.value,
    repetitions: 0,
    interval: 1,
    easeFactor: 2.5,
    nextReviewDate: new Date(),
    lastReviewed: null
  });

  alert("Dodano");
  calculateMastery();
};

// ================= STUDY =================

document.getElementById("studyBtn").onclick = async () => {
  const snapshot = await getDocs(collection(db, "users", currentUser.uid, "cards"));
  studyCards = [];

  snapshot.forEach(docSnap => {
    const data = docSnap.data();
    if (
      data.groupId === currentGroupId &&
      new Date() >= data.nextReviewDate.toDate()
    ) {
      studyCards.push({ id: docSnap.id, ...data });
    }
  });

  currentCardIndex = 0;

  if (studyCards.length === 0) {
    alert("Brak kart do powtórki");
    return;
  }

  showCard();
  document.getElementById("studyView").classList.remove("hidden");
};

function showCard() {
  const card = studyCards[currentCardIndex];
  flashcard.innerText = card.word;
  answerSection.classList.add("hidden");
}

showAnswerBtn.onclick = () => {
  const card = studyCards[currentCardIndex];
  answer.innerText =
    card.translation + " (" + card.transcription + ")";
  answerSection.classList.remove("hidden");
};

speakBtn.onclick = () => {
  const utterance = new SpeechSynthesisUtterance(
    studyCards[currentCardIndex].word
  );
  utterance.lang = "ko-KR";
  speechSynthesis.speak(utterance);
};

knowBtn.onclick = () => updateCard(true);
dontKnowBtn.onclick = () => updateCard(false);

async function updateCard(correct) {
  const card = studyCards[currentCardIndex];

  let { repetitions, interval, easeFactor } = card;

  if (!correct) {
    repetitions = 0;
    interval = 1;
    easeFactor = Math.max(1.3, easeFactor - 0.2);
  } else {
    repetitions += 1;

    if (repetitions === 1) interval = 1;
    else if (repetitions === 2) interval = 3;
    else interval = Math.round(interval * easeFactor);

    easeFactor += 0.1;
  }

  const nextDate = new Date();
  nextDate.setDate(nextDate.getDate() + interval);

  await updateDoc(doc(db, "users", currentUser.uid, "cards", card.id), {
    repetitions,
    interval,
    easeFactor,
    nextReviewDate: nextDate,
    lastReviewed: new Date()
  });

  await updateStreakIfNeeded();
  await calculateMastery();

  currentCardIndex++;

  if (currentCardIndex < studyCards.length) {
    showCard();
  } else {
    alert("Sesja zakończona 🔥");
    document.getElementById("studyView").classList.add("hidden");
  }
}
